import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { motion } from "framer-motion";

interface PlayerResult {
  name: string;
  score: number;
  successRate: number;
  status: "WON" | "BUST";
}

interface EndScreenProps {
  players: PlayerResult[];
  onNewGame: () => void;
}

export default function EndScreen({ players, onNewGame }: EndScreenProps) {
  const [bestScore, setBestScore] = useState<number | null>(null);
  const [isNewRecord, setIsNewRecord] = useState(false);

  const isTwoPlayer = players.length === 2;

  // For best score we use player 1's score (or the winner's score in 2p)
  const topScore = isTwoPlayer
    ? Math.max(...players.filter(p => p.status === "WON").map(p => p.score), -Infinity)
    : players[0].score;

  useEffect(() => {
    const saved = localStorage.getItem("superBob27_bestScore");
    const currentBest = saved ? parseInt(saved, 10) : null;
    setBestScore(currentBest);

    const p1 = players[0];
    if (p1.status === "WON") {
      if (currentBest === null || p1.score > currentBest) {
        localStorage.setItem("superBob27_bestScore", p1.score.toString());
        setIsNewRecord(true);
        setBestScore(p1.score);
      }
    }
  }, [players]);

  // Determine winner in 2p mode
  const getWinner = () => {
    if (!isTwoPlayer) return null;
    const [p1, p2] = players;
    if (p1.status === "BUST" && p2.status === "BUST") return "draw_bust";
    if (p1.status === "BUST") return p2.name;
    if (p2.status === "BUST") return p1.name;
    if (p1.score === p2.score) return "draw";
    return p1.score > p2.score ? p1.name : p2.name;
  };

  const winner = getWinner();

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-md mx-auto p-6 min-h-[100dvh] flex flex-col justify-center gap-6 text-center"
    >
      {/* Header */}
      <div className="space-y-3">
        {isTwoPlayer ? (
          <>
            {winner === "draw" || winner === "draw_bust" ? (
              <h1 className="text-5xl font-black text-primary tracking-tight">DRAW!</h1>
            ) : (
              <>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", bounce: 0.6 }}
                  className="text-4xl mb-2"
                >
                  🏆
                </motion.div>
                <h1 className="text-5xl font-black text-primary tracking-tight">
                  {winner} WINS!
                </h1>
              </>
            )}
          </>
        ) : (
          <>
            {players[0].status === "BUST" ? (
              <>
                <h1 className="text-6xl font-black text-destructive tracking-tighter">BUST</h1>
                <p className="text-xl text-muted-foreground font-medium">Score dropped below 0.</p>
              </>
            ) : (
              <>
                {isNewRecord && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", bounce: 0.6 }}
                    className="text-4xl mb-2"
                  >
                    🏆
                  </motion.div>
                )}
                <h1 className="text-5xl font-black text-primary tracking-tight">GAME OVER</h1>
                {isNewRecord && (
                  <p className="text-xl text-primary font-bold animate-pulse">NEW RECORD!</p>
                )}
              </>
            )}
          </>
        )}
      </div>

      {/* Player cards */}
      <div className={`grid gap-4 ${isTwoPlayer ? "grid-cols-2" : "grid-cols-1"}`}>
        {players.map((player, idx) => {
          const isWinnerCard = isTwoPlayer && winner === player.name;
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.15 }}
              className={`bg-card rounded-2xl p-5 border shadow-xl space-y-4 ${
                isWinnerCard ? "border-primary" : "border-border"
              }`}
            >
              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-1">
                  {isTwoPlayer ? `Player ${idx + 1}` : "Player"}
                </div>
                <div className="text-lg font-bold text-white truncate">{player.name}</div>
              </div>

              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-1">Score</div>
                <div className={`text-5xl font-black ${player.status === "BUST" ? "text-destructive" : "text-primary"}`}>
                  {player.score}
                </div>
                {player.status === "BUST" && (
                  <div className="text-xs text-destructive font-bold mt-1">BUST</div>
                )}
              </div>

              <div className="pt-3 border-t border-border">
                <div className="text-xs text-muted-foreground uppercase tracking-wider font-bold mb-1">Success</div>
                <div className="text-lg font-bold text-white">{Math.round(player.successRate)}%</div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Best Score (single player only) */}
      {!isTwoPlayer && (
        <div className="bg-card rounded-xl p-4 border border-border">
          <div className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-1">Best Score</div>
          <div className="text-2xl font-bold text-white">{bestScore !== null ? bestScore : "-"}</div>
        </div>
      )}

      <Button
        size="lg"
        className="w-full py-8 text-2xl font-bold mt-2"
        onClick={onNewGame}
        data-testid="button-new-game"
      >
        NEW GAME
      </Button>
    </motion.div>
  );
}
