import { useState, useMemo } from "react";
import { GameSettings, RoundResult, BOT_LEVELS, simulateBotGame, getDoubleValue } from "../../lib/gameLogic";
import GameScreen from "./GameScreen";
import BotRoundDisplay from "./BotRoundDisplay";
import EndScreen from "./EndScreen";
import { Button } from "../ui/button";
import { motion, AnimatePresence } from "framer-motion";

interface MatchManagerProps {
  settings: GameSettings;
  onExit: () => void;
}

type Phase =
  | "PLAYER_TURN"
  | "HANDOFF_TO_OPPONENT"   // show "pass device" screen before P2 or "bot playing" before bot
  | "OPPONENT_TURN"
  | "DONE";

interface PlayerState {
  score: number;
  hits: number;
  dartsThrown: number;
  bust: boolean;
}

function nextDouble(d: number): number {
  const n = d + 1;
  return n === 21 ? 25 : n;
}

export default function MatchManager({ settings, onExit }: MatchManagerProps) {
  const isBot = settings.playerCount === "BOT";
  const is2P = settings.playerCount === 2;

  const botLevel = useMemo(
    () => BOT_LEVELS.find(l => l.id === (settings.botLevelId ?? 3)) ?? BOT_LEVELS[2],
    [settings.botLevelId]
  );

  // Pre-compute all bot rounds upfront (only used in BOT mode)
  const botRounds = useMemo(
    () => isBot ? simulateBotGame(settings, botLevel) : [],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const [matchRound, setMatchRound] = useState(1); // 1-21
  const [currentDouble, setCurrentDouble] = useState(1); // 1-20, then 25
  const [phase, setPhase] = useState<Phase>("PLAYER_TURN");

  const [player, setPlayer] = useState<PlayerState>({ score: 27, hits: 0, dartsThrown: 0, bust: false });
  const [opponent, setOpponent] = useState<PlayerState>({ score: 27, hits: 0, dartsThrown: 0, bust: false });

  // Mini scoreboard shown at top in HANDOFF phase
  const opponentName = isBot ? `${botLevel.icon} ${botLevel.name}` : settings.player2Name;

  function handlePlayerRoundDone(result: RoundResult) {
    const newPlayer: PlayerState = {
      score: result.finalScore,
      hits: player.hits + result.hits,
      dartsThrown: player.dartsThrown + result.dartsThrown,
      bust: result.bust,
    };
    setPlayer(newPlayer);

    if (result.bust) {
      // Player busted — match ends immediately
      setPhase("DONE");
      return;
    }

    setPhase("HANDOFF_TO_OPPONENT");
  }

  function handleOpponentRoundDone(result: RoundResult) {
    const newOpponent: PlayerState = {
      score: result.finalScore,
      hits: opponent.hits + result.hits,
      dartsThrown: opponent.dartsThrown + result.dartsThrown,
      bust: result.bust,
    };
    setOpponent(newOpponent);

    if (result.bust || matchRound >= 21) {
      setPhase("DONE");
      return;
    }

    // Advance to next round
    const nd = nextDouble(currentDouble);
    setCurrentDouble(nd);
    setMatchRound(r => r + 1);
    setPhase("PLAYER_TURN");
  }

  function handleBotRoundDone() {
    // Bot round result already pre-computed — use it to update opponent state
    const botRound = botRounds[matchRound - 1]; // 0-indexed
    if (!botRound) {
      setPhase("DONE");
      return;
    }

    const totalBotPoints = botRound.darts.reduce((s, d) => s + d.points, 0);
    const penalty = botRound.doubleHit ? 0 : -getDoubleValue(botRound.currentDouble);
    const newScore = botRound.scoreAfter;
    const newHits = botRound.darts.filter(d => d.points > 0).length;

    const newOpponent: PlayerState = {
      score: newScore,
      hits: opponent.hits + newHits,
      dartsThrown: opponent.dartsThrown + botRound.darts.length,
      bust: botRound.bust,
    };
    // Suppress unused warning
    void totalBotPoints; void penalty;
    setOpponent(newOpponent);

    if (botRound.bust || matchRound >= 21) {
      setPhase("DONE");
      return;
    }

    const nd = nextDouble(currentDouble);
    setCurrentDouble(nd);
    setMatchRound(r => r + 1);
    setPhase("PLAYER_TURN");
  }

  // Build end screen results
  const playerSuccessRate = player.dartsThrown > 0 ? (player.hits / player.dartsThrown) * 100 : 0;
  const opponentSuccessRate = opponent.dartsThrown > 0 ? (opponent.hits / opponent.dartsThrown) * 100 : 0;

  const endResults = [
    { name: settings.playerName, score: player.score, successRate: playerSuccessRate, status: player.bust ? "BUST" as const : "WON" as const },
    { name: opponentName, score: opponent.score, successRate: opponentSuccessRate, status: (opponent.bust ? "BUST" : "WON") as "BUST" | "WON" },
  ];

  // Current bot round for display
  const currentBotRound = botRounds[matchRound - 1];

  return (
    <div className="relative">
      {/* Scoreboard banner (always visible during play) */}
      {phase !== "DONE" && (
        <div className="flex justify-center gap-0 text-xs font-bold uppercase tracking-widest border-b border-border bg-card">
          <div className="flex-1 text-center py-2 px-3 border-r border-border">
            <span className="text-muted-foreground block text-[10px]">{settings.playerName}</span>
            <span className={`text-base font-black ${player.score < 0 ? "text-destructive" : "text-primary"}`}>
              {player.score}
            </span>
          </div>
          <div className="flex items-center px-3 text-muted-foreground text-[10px]">
            R{matchRound}/21
          </div>
          <div className="flex-1 text-center py-2 px-3 border-l border-border">
            <span className="text-muted-foreground block text-[10px]">{opponentName}</span>
            <span className={`text-base font-black ${opponent.score < 0 ? "text-destructive" : "text-purple-400"}`}>
              {opponent.score}
            </span>
          </div>
        </div>
      )}

      <AnimatePresence mode="wait">

        {/* Player's turn */}
        {phase === "PLAYER_TURN" && (
          <motion.div key={`player-${matchRound}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <GameScreen
              settings={settings}
              startScore={player.score}
              startRound={matchRound}
              startDouble={currentDouble}
              onRoundDone={handlePlayerRoundDone}
              onExit={onExit}
            />
          </motion.div>
        )}

        {/* Handoff screen */}
        {phase === "HANDOFF_TO_OPPONENT" && (
          <motion.div
            key="handoff"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center min-h-[100dvh] gap-8 p-8 text-center max-w-md mx-auto"
          >
            <div className="space-y-2">
              <div className="text-5xl mb-4">{isBot ? "🤖" : "👋"}</div>
              <h2 className="text-3xl font-black text-white">
                {isBot ? "Bot's Turn" : `${settings.player2Name}'s Turn`}
              </h2>
              <p className="text-muted-foreground">
                {isBot
                  ? `Watching ${botLevel.name} play D${currentDouble === 25 ? "B" : currentDouble}...`
                  : `Pass the device to ${settings.player2Name}`}
              </p>
            </div>

            {/* Scores */}
            <div className="grid grid-cols-2 gap-4 w-full">
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{settings.playerName}</div>
                <div className="text-3xl font-black text-primary">{player.score}</div>
              </div>
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{opponentName}</div>
                <div className="text-3xl font-black text-purple-400">{opponent.score}</div>
              </div>
            </div>

            {isBot ? (
              <Button
                size="lg"
                className="w-full py-7 text-xl font-black bg-purple-600 hover:bg-purple-700"
                onClick={() => setPhase("OPPONENT_TURN")}
                data-testid="btn-watch-bot"
              >
                WATCH BOT THROW →
              </Button>
            ) : (
              <Button
                size="lg"
                className="w-full py-7 text-xl font-black"
                onClick={() => setPhase("OPPONENT_TURN")}
                data-testid="btn-p2-ready"
              >
                {settings.player2Name} READY →
              </Button>
            )}
          </motion.div>
        )}

        {/* Opponent's turn */}
        {phase === "OPPONENT_TURN" && (
          <motion.div key={`opponent-${matchRound}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {isBot && currentBotRound ? (
              <BotRoundDisplay
                round={currentBotRound}
                runningScore={opponent.score}
                levelIcon={botLevel.icon}
                levelName={botLevel.name}
                onDone={handleBotRoundDone}
              />
            ) : (
              // 2-player: P2 plays same round
              <GameScreen
                settings={{ ...settings, playerName: settings.player2Name }}
                startScore={opponent.score}
                startRound={matchRound}
                startDouble={currentDouble}
                onRoundDone={handleOpponentRoundDone}
                onExit={onExit}
              />
            )}
          </motion.div>
        )}

        {/* End screen */}
        {phase === "DONE" && (
          <motion.div key="done" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <EndScreen
              players={endResults}
              onNewGame={onExit}
            />
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
