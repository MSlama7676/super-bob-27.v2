import { useState, useEffect, useRef } from "react";
import { GameSettings, BotLevel, BotRoundResult, BotDartAction, simulateBotGame, getDoubleValue, BOT_LEVELS } from "../../lib/gameLogic";
import { Button } from "../ui/button";
import { motion, AnimatePresence } from "framer-motion";

interface BotGameScreenProps {
  settings: GameSettings;
  onFinished: (score: number, successRate: number, status: "WON" | "BUST") => void;
}

const ACTION_DELAY_MS = 1100; // delay between each dart action
const ROUND_PAUSE_MS = 900;   // pause between rounds

function actionLabel(dart: BotDartAction): string {
  switch (dart.actionType) {
    case "entry_multi":  return `${dart.label} ✓`;
    case "entry_single": return `${dart.label} ✓`;
    case "entry_miss":   return `${dart.label} ✗`;
    case "double_hit":   return `${dart.label} ✓`;
    case "double_miss":  return `${dart.label} ✗`;
    case "bull_hit":     return `BULL ✓`;
    case "bull_miss":    return `BULL ✗`;
  }
}

function actionColor(dart: BotDartAction): string {
  switch (dart.actionType) {
    case "entry_multi":
    case "entry_single":
    case "double_hit":
    case "bull_hit":
      return "text-green-400";
    case "entry_miss":
    case "double_miss":
    case "bull_miss":
      return "text-red-400";
  }
}

function pointsLabel(dart: BotDartAction): string {
  if (dart.points > 0) return `+${dart.points}`;
  if (dart.actionType === "entry_single") return "entry";
  return "miss";
}

export default function BotGameScreen({ settings, onFinished }: BotGameScreenProps) {
  const level: BotLevel = BOT_LEVELS.find(l => l.id === (settings.botLevelId ?? 3)) ?? BOT_LEVELS[2];

  // Pre-compute entire bot game
  const [rounds] = useState<BotRoundResult[]>(() => simulateBotGame(settings, level));

  const [currentRoundIdx, setCurrentRoundIdx] = useState(0);
  const [dartIdx, setDartIdx] = useState(-1); // -1 = none shown yet, 0/1/2 = darts revealed
  const [showPenalty, setShowPenalty] = useState(false);
  const [displayScore, setDisplayScore] = useState(27);
  const [skipped, setSkipped] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const totalRounds = rounds.length;
  const currentRound = rounds[currentRoundIdx] ?? null;

  // Calculate cumulative stats
  const totalDarts = rounds.slice(0, currentRoundIdx + 1).reduce((a, r) => a + r.darts.length, 0);
  const successfulDarts = rounds.slice(0, currentRoundIdx + 1).reduce((a, r) => {
    return a + r.darts.filter(d => d.points > 0).length;
  }, 0);

  function scheduleNext(fn: () => void, ms: number) {
    timerRef.current = setTimeout(fn, ms);
  }

  function clearTimer() {
    if (timerRef.current) clearTimeout(timerRef.current);
  }

  // Animation sequence for a round
  useEffect(() => {
    if (skipped || !currentRound) return;
    clearTimer();

    if (dartIdx < 0) {
      // Start dart 0 after short delay
      scheduleNext(() => setDartIdx(0), 600);
    } else if (dartIdx < 2) {
      scheduleNext(() => setDartIdx(d => d + 1), ACTION_DELAY_MS);
    } else {
      // All 3 darts shown — show penalty / score update
      scheduleNext(() => {
        setDisplayScore(currentRound.scoreAfter);
        setShowPenalty(true);
        // Advance to next round
        scheduleNext(() => {
          setShowPenalty(false);
          if (currentRound.bust || currentRoundIdx + 1 >= totalRounds) {
            finish();
          } else {
            setCurrentRoundIdx(r => r + 1);
            setDartIdx(-1);
          }
        }, ROUND_PAUSE_MS + 400);
      }, ACTION_DELAY_MS);
    }

    return clearTimer;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dartIdx, currentRoundIdx, skipped]);

  function finish() {
    const lastRound = rounds[rounds.length - 1];
    const finalScore = lastRound.scoreAfter;
    const status = lastRound.bust ? "BUST" : "WON";
    const allDarts = rounds.reduce((a, r) => a + r.darts.length, 0);
    const allHits = rounds.reduce((a, r) => a + r.darts.filter(d => d.points > 0).length, 0);
    const successRate = allDarts > 0 ? (allHits / allDarts) * 100 : 0;
    onFinished(finalScore, successRate, status);
  }

  function handleSkip() {
    clearTimer();
    setSkipped(true);
    finish();
  }

  if (!currentRound) return null;

  const targetLabel = currentRound.currentDouble === 25 ? "DB" : `D${currentRound.currentDouble}`;
  const doubleVal = getDoubleValue(currentRound.currentDouble);

  return (
    <div className="flex flex-col h-[100dvh] max-w-md mx-auto p-4">

      {/* Header */}
      <div className="flex justify-between items-center text-sm font-bold uppercase tracking-widest text-muted-foreground mb-4">
        <span>{level.icon} {level.name}</span>
        <span>{totalDarts > 0 ? Math.round((successfulDarts / totalDarts) * 100) : 0}% Hits</span>
      </div>

      {/* Info strip */}
      <div className="flex justify-between items-center bg-card rounded-lg p-3 border border-border/50 mb-6">
        <div className="text-sm font-bold text-purple-400 px-2 py-1 rounded bg-purple-400/10">
          BOT
        </div>
        <div className="text-3xl font-black tracking-tight text-white">
          {targetLabel}
        </div>
        <div className="text-sm font-bold text-muted-foreground">
          R {currentRound.round}/21
        </div>
      </div>

      {/* Score */}
      <div className="flex-1 flex flex-col items-center justify-center mb-6 relative">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={displayScore}
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 1.2, opacity: 0, y: -20 }}
            className={`text-8xl font-black tracking-tighter tabular-nums ${displayScore < 0 ? "text-destructive" : "text-primary"}`}
          >
            {displayScore}
          </motion.div>
        </AnimatePresence>
        <div className="absolute -bottom-6 text-muted-foreground font-bold tracking-widest uppercase text-sm">
          SCORE
        </div>
      </div>

      {/* Dart actions */}
      <div className="bg-card border border-border rounded-2xl p-5 mb-6 space-y-3 min-h-[160px]">
        <div className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-4">
          Throwing...
        </div>
        {[0, 1, 2].map(i => {
          const dart = currentRound.darts[i];
          const revealed = i <= dartIdx;
          return (
            <AnimatePresence key={i}>
              {revealed && dart && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-muted-foreground text-sm font-bold w-5">{i + 1}.</span>
                    <span className={`text-lg font-black ${actionColor(dart)}`}>
                      {actionLabel(dart)}
                    </span>
                  </div>
                  <span className={`text-sm font-bold tabular-nums ${dart.points > 0 ? "text-green-400" : "text-muted-foreground"}`}>
                    {pointsLabel(dart)}
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          );
        })}

        {/* Penalty line */}
        <AnimatePresence>
          {showPenalty && !currentRound.doubleHit && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between pt-2 border-t border-border"
            >
              <span className="text-sm font-bold text-destructive uppercase tracking-wider">Miss Penalty</span>
              <span className="text-sm font-bold text-destructive">−{doubleVal}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-border rounded-full h-1.5 mb-4">
        <motion.div
          className="bg-purple-500 h-1.5 rounded-full"
          animate={{ width: `${(currentRound.round / 21) * 100}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>

      <Button
        variant="outline"
        className="border-border text-muted-foreground font-bold"
        onClick={handleSkip}
        data-testid="btn-bot-skip"
      >
        SKIP →
      </Button>
    </div>
  );
}
