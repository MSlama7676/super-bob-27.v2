import { useState, useEffect } from "react";
import { GameSettings, GameState, RoundResult, getEntryValue, getDoubleValue } from "../../lib/gameLogic";
import { Button } from "../ui/button";
import { useToast } from "../../hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "../ui/dialog";
import { motion, AnimatePresence } from "framer-motion";

interface GameScreenProps {
  settings: GameSettings;
  // Full-game mode (solo / legacy)
  onGameOver?: (score: number, successRate: number, status: "WON" | "BUST") => void;
  // Single-round mode (used by MatchManager)
  startScore?: number;
  startRound?: number;
  startDouble?: number;
  onRoundDone?: (result: RoundResult) => void;
  onExit: () => void;
}

const getTargetDisplay = (currentDouble: number) => {
  if (currentDouble === 25) return "BULL";
  return `D${currentDouble}`;
};

export default function GameScreen({
  settings,
  onGameOver,
  startScore,
  startRound,
  startDouble,
  onRoundDone,
  onExit,
}: GameScreenProps) {
  const { toast } = useToast();
  const [history, setHistory] = useState<GameState[]>([]);
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  const singleRoundMode = !!onRoundDone;

  const [state, setState] = useState<GameState>({
    score: startScore ?? 27,
    currentDouble: startDouble ?? 1,
    round: startRound ?? 1,
    dartsRemaining: 3,
    enteredGame: false,
    doubleHit: false,
    hits: 0,
    totalDartsThrown: 0,
    status: "PLAYING",
    pendingEntryBonus: 0,
  });

  const saveHistory = () => {
    setHistory(prev => [...prev, { ...state }]);
  };

  const handleEntry = (multiplier: number) => {
    if (state.dartsRemaining <= 0) return;
    if (state.enteredGame) {
      toast({ title: "Already entered", description: "You have already hit the entry target this round." });
      return;
    }
    saveHistory();
    const entryValue = getEntryValue(settings.version);
    // Single (×1) → 0 points, just entry.
    // Triple/Double (×>1) → points are PENDING, added only if a double is hit this round.
    const bonus = multiplier === 1 ? 0 : entryValue * multiplier;
    setState(prev => ({
      ...prev,
      dartsRemaining: prev.dartsRemaining - 1,
      enteredGame: true,
      pendingEntryBonus: bonus,
      hits: prev.hits + 1,
      totalDartsThrown: prev.totalDartsThrown + 1,
    }));
  };

  const handleDouble = () => {
    if (state.dartsRemaining <= 0) return;
    if (!state.enteredGame) {
      const msg = settings.gameMode === "CLASSIC" ? "Hit SINGLE or TRIPLE first" : "Hit SINGLE or DOUBLE first";
      toast({ title: "Entry required", description: msg, variant: "destructive" });
      return;
    }
    saveHistory();
    const addedScore = getDoubleValue(state.currentDouble);
    setState(prev => ({
      ...prev,
      score: prev.score + addedScore,
      dartsRemaining: prev.dartsRemaining - 1,
      doubleHit: true,
      hits: prev.hits + 1,
      totalDartsThrown: prev.totalDartsThrown + 1,
    }));
  };

  const handleBullseyeBonus = () => {
    if (state.dartsRemaining !== 1) {
      toast({ title: "3rd Dart Only", description: "Bullseye Bonus can only be used as the 3rd dart.", variant: "destructive" });
      return;
    }
    if (!state.enteredGame) {
      toast({ title: "Entry required", description: "Must enter before using bonus.", variant: "destructive" });
      return;
    }
    if (!state.doubleHit) {
      toast({ title: "Double required", description: "You must hit the Double on the 2nd dart before using Bull.", variant: "destructive" });
      return;
    }
    saveHistory();
    const bullValue = getDoubleValue(state.currentDouble) * 3;
    setState(prev => ({
      ...prev,
      score: prev.score + bullValue,
      dartsRemaining: prev.dartsRemaining - 1,
      hits: prev.hits + 1,
      totalDartsThrown: prev.totalDartsThrown + 1,
    }));
  };

  const handleNextRound = () => {
    saveHistory();
    let newScore = state.score;
    // Pending entry bonus (T/D entry) only counts if a double was hit
    if (state.doubleHit) {
      newScore += state.pendingEntryBonus;
    }
    // Miss penalty if no double hit
    if (!state.doubleHit) {
      newScore -= getDoubleValue(state.currentDouble);
    }

    if (singleRoundMode) {
      const bust = newScore < 0;
      setState(prev => ({ ...prev, score: newScore, pendingEntryBonus: 0 }));
      onRoundDone!({
        roundNumber: state.round,
        currentDouble: state.currentDouble,
        finalScore: newScore,
        bust,
        doubleHit: state.doubleHit,
        dartsThrown: state.totalDartsThrown,
        hits: state.hits,
      });
      return;
    }

    // Full-game mode
    if (newScore < 0) {
      setState(prev => ({ ...prev, score: newScore, pendingEntryBonus: 0, status: "BUST" }));
      return;
    }
    if (state.round >= 21) {
      setState(prev => ({ ...prev, score: newScore, pendingEntryBonus: 0, status: "WON" }));
      return;
    }
    let nextDouble = state.currentDouble + 1;
    if (nextDouble === 21) nextDouble = 25;
    setState(prev => ({
      ...prev,
      score: newScore,
      currentDouble: nextDouble,
      round: prev.round + 1,
      dartsRemaining: 3,
      enteredGame: false,
      doubleHit: false,
      pendingEntryBonus: 0,
    }));
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const previousState = history[history.length - 1];
    setState(previousState);
    setHistory(prev => prev.slice(0, -1));
  };

  // Full-game mode end condition
  useEffect(() => {
    if (!singleRoundMode && state.status !== "PLAYING") {
      const successRate = state.totalDartsThrown > 0 ? (state.hits / state.totalDartsThrown) * 100 : 0;
      onGameOver?.(state.score, successRate, state.status);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.status]);

  const entryLabelSingle = `S${settings.version}`;
  const entryLabelMulti = settings.gameMode === "CLASSIC" ? `T${settings.version}` : `D${settings.version}`;
  const entryMultiplier = settings.gameMode === "CLASSIC" ? 3 : 2;
  const successRateDisplay = state.totalDartsThrown > 0 ? Math.round((state.hits / state.totalDartsThrown) * 100) : 0;

  return (
    <div className="flex flex-col h-[100dvh] max-w-md mx-auto p-4 safe-area-inset-bottom">

      {/* Top Bar */}
      <div className="flex justify-between items-center text-muted-foreground text-sm font-medium mb-4 uppercase tracking-wider">
        <span>{settings.playerName}</span>
        <span>{successRateDisplay}% Hits</span>
      </div>

      {/* Info Strip */}
      <div className="flex justify-between items-center bg-card rounded-lg p-3 border border-border/50 mb-6 shadow-sm">
        <div className="text-sm font-bold text-primary px-2 py-1 rounded bg-primary/10">
          {settings.gameMode}
        </div>
        <div className="text-3xl font-black tracking-tight text-white">
          {getTargetDisplay(state.currentDouble)}
        </div>
        <div className="text-sm font-bold text-muted-foreground">
          R {state.round}/21
        </div>
      </div>

      {/* Score Display */}
      <div className="flex-1 flex flex-col items-center justify-center mb-8 relative">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={state.score}
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 1.2, opacity: 0, y: -20 }}
            className={`text-8xl md:text-[8rem] font-black tracking-tighter tabular-nums ${state.score < 0 ? "text-destructive" : "text-primary"}`}
            style={{ textShadow: "0 0 40px rgba(240, 196, 25, 0.1)" }}
          >
            {state.score}
          </motion.div>
        </AnimatePresence>
        {/* Pending entry bonus indicator */}
        <AnimatePresence>
          {state.pendingEntryBonus > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              className="mt-2 px-3 py-1 rounded-full bg-blue-600/20 border border-blue-600/40 text-blue-400 text-sm font-bold"
            >
              +{state.pendingEntryBonus} pending (hit double to confirm)
            </motion.div>
          )}
        </AnimatePresence>
        <div className="absolute -bottom-6 text-muted-foreground font-bold tracking-widest uppercase text-sm">
          SCORE
        </div>
      </div>

      {/* Darts Tracker */}
      <div className="flex justify-center gap-4 mb-8">
        {[1, 2, 3].map((dart) => (
          <motion.div
            key={dart}
            initial={false}
            animate={{
              opacity: dart <= state.dartsRemaining ? 1 : 0.2,
              scale: dart <= state.dartsRemaining ? 1 : 0.9,
              rotate: dart <= state.dartsRemaining ? 0 : 15,
            }}
            className="w-4 h-12 bg-white rounded-full relative overflow-hidden"
          >
            <div className="absolute top-0 inset-x-0 h-4 bg-primary/80 rounded-t-full" />
          </motion.div>
        ))}
      </div>

      {/* Controls */}
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-3">
          <Button
            className="h-16 text-xl font-bold bg-blue-600 hover:bg-blue-700 text-white"
            onClick={() => handleEntry(1)}
            disabled={state.enteredGame || state.dartsRemaining === 0}
            data-testid="btn-entry-single"
          >
            {entryLabelSingle}
          </Button>
          <Button
            className="h-16 text-xl font-bold bg-blue-600 hover:bg-blue-700 text-white"
            onClick={() => handleEntry(entryMultiplier)}
            disabled={state.enteredGame || state.dartsRemaining === 0}
            data-testid="btn-entry-multi"
          >
            {entryLabelMulti}
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Button
            className="h-20 text-2xl font-black bg-[#f0c419] hover:bg-[#e0b408] text-black"
            onClick={handleDouble}
            disabled={!state.enteredGame || state.dartsRemaining === 0}
            data-testid="btn-double"
          >
            {getTargetDisplay(state.currentDouble)}
          </Button>
          <Button
            className="h-20 text-xl font-bold bg-purple-600 hover:bg-purple-700 text-white leading-tight"
            onClick={handleBullseyeBonus}
            disabled={!state.enteredGame || state.dartsRemaining !== 1 || !state.doubleHit}
            data-testid="btn-bullseye"
          >
            BULL<br />+{getDoubleValue(state.currentDouble) * 3}
          </Button>
        </div>

        <Button
          variant="destructive"
          className="h-16 text-xl font-black tracking-widest uppercase mt-2 shadow-lg"
          onClick={handleNextRound}
          data-testid="btn-next-round"
        >
          NEXT ROUND
        </Button>

        <div className="grid grid-cols-2 gap-3 mt-4">
          <Button
            variant="outline"
            onClick={handleUndo}
            disabled={history.length === 0}
            className="border-border text-muted-foreground font-bold"
            data-testid="btn-undo"
          >
            UNDO
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowExitConfirm(true)}
            className="border-border text-muted-foreground font-bold"
            data-testid="btn-exit"
          >
            EXIT
          </Button>
        </div>
      </div>

      <Dialog open={showExitConfirm} onOpenChange={setShowExitConfirm}>
        <DialogContent className="sm:max-w-md border-border bg-card">
          <DialogHeader>
            <DialogTitle>Exit Game?</DialogTitle>
            <DialogDescription>
              Are you sure you want to exit? Your current progress will be lost.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2 sm:justify-between">
            <Button variant="outline" onClick={() => setShowExitConfirm(false)} className="flex-1">
              Resume
            </Button>
            <Button variant="destructive" onClick={onExit} className="flex-1">
              Exit Game
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
