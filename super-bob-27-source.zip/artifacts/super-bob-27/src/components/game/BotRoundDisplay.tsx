import { useState, useEffect, useRef } from "react";
import { BotRoundResult, BotDartAction, getDoubleValue } from "../../lib/gameLogic";
import { Button } from "../ui/button";
import { motion, AnimatePresence } from "framer-motion";

interface BotRoundDisplayProps {
  round: BotRoundResult;
  runningScore: number; // bot score BEFORE this round
  levelIcon: string;
  levelName: string;
  onDone: () => void;
}

const ACTION_DELAY = 1000;

function actionLabel(dart: BotDartAction): string {
  switch (dart.actionType) {
    case "entry_multi":  return `${dart.label} ✓`;
    case "entry_single": return `${dart.label} ✓`;
    case "entry_miss":   return `${dart.label} ✗`;
    case "double_hit":   return `${dart.label} ✓`;
    case "double_miss":  return `${dart.label} ✗`;
    case "bull_hit":     return "BULL ✓";
    case "bull_miss":    return "BULL ✗";
  }
}

function actionColor(dart: BotDartAction): string {
  return ["entry_multi","entry_single","double_hit","bull_hit"].includes(dart.actionType)
    ? "text-green-400" : "text-red-400";
}

export default function BotRoundDisplay({ round, runningScore, levelIcon, levelName, onDone }: BotRoundDisplayProps) {
  const [dartIdx, setDartIdx] = useState(-1);
  const [showResult, setShowResult] = useState(false);
  const [displayScore, setDisplayScore] = useState(runningScore);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const targetLabel = round.currentDouble === 25 ? "DB" : `D${round.currentDouble}`;
  const doubleVal = getDoubleValue(round.currentDouble);

  function schedule(fn: () => void, ms: number) {
    timer.current = setTimeout(fn, ms);
  }
  function clear() { if (timer.current) clearTimeout(timer.current); }

  useEffect(() => {
    clear();
    if (dartIdx < 0) {
      schedule(() => setDartIdx(0), 500);
    } else if (dartIdx < 2) {
      schedule(() => setDartIdx(i => i + 1), ACTION_DELAY);
    } else {
      // All 3 darts shown — reveal result, then auto-advance
      schedule(() => {
        setDisplayScore(round.scoreAfter);
        setShowResult(true);
        // Auto-advance to player's turn after 1.8s
        schedule(onDone, 1800);
      }, ACTION_DELAY);
    }
    return clear;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dartIdx]);

  function handleSkip() {
    clear();
    setDisplayScore(round.scoreAfter);
    setShowResult(true);
    setDartIdx(2);
  }

  return (
    <div className="flex flex-col h-[100dvh] max-w-md mx-auto p-4">

      {/* Top bar */}
      <div className="flex justify-between items-center text-sm font-bold uppercase tracking-widest text-muted-foreground mb-4">
        <span>{levelIcon} {levelName}</span>
        <span className="text-purple-400">BOT</span>
      </div>

      {/* Info strip */}
      <div className="flex justify-between items-center bg-card rounded-lg p-3 border border-border/50 mb-6">
        <div className="text-sm font-bold text-purple-400 px-2 py-1 rounded bg-purple-400/10">BOT TURN</div>
        <div className="text-3xl font-black tracking-tight text-white">{targetLabel}</div>
        <div className="text-sm font-bold text-muted-foreground">R {round.round}/21</div>
      </div>

      {/* Score */}
      <div className="flex-1 flex flex-col items-center justify-center mb-6 relative">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={displayScore}
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 1.2, opacity: 0, y: -20 }}
            className={`text-8xl font-black tracking-tighter tabular-nums ${displayScore < 0 ? "text-destructive" : "text-purple-400"}`}
          >
            {displayScore}
          </motion.div>
        </AnimatePresence>
        <div className="absolute -bottom-6 text-muted-foreground font-bold tracking-widest uppercase text-sm">SCORE</div>
      </div>

      {/* Darts */}
      <div className="bg-card border border-border rounded-2xl p-5 mb-6 space-y-3 min-h-[160px]">
        <div className="text-xs text-muted-foreground uppercase tracking-widest font-bold mb-3">Throwing...</div>
        {[0, 1, 2].map(i => {
          const dart = round.darts[i];
          const revealed = i <= dartIdx;
          return (
            <AnimatePresence key={i}>
              {revealed && dart && (
                <motion.div
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-muted-foreground text-sm font-bold w-5">{i + 1}.</span>
                    <span className={`text-lg font-black ${actionColor(dart)}`}>{actionLabel(dart)}</span>
                  </div>
                  <span className={`text-sm font-bold tabular-nums ${dart.points > 0 ? "text-green-400" : "text-muted-foreground"}`}>
                    {dart.points > 0 ? `+${dart.points}` : dart.actionType === "entry_single" ? "entry" : "miss"}
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          );
        })}

        <AnimatePresence>
          {showResult && !round.doubleHit && (
            <motion.div
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between pt-2 border-t border-border"
            >
              <span className="text-sm font-bold text-destructive uppercase tracking-wider">Miss Penalty</span>
              <span className="text-sm font-bold text-destructive">−{doubleVal}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          variant="outline"
          className="border-border text-muted-foreground font-bold col-span-2"
          onClick={handleSkip}
          data-testid="btn-bot-skip"
        >
          SKIP →
        </Button>
      </div>
    </div>
  );
}
