import { useState } from "react";
import { GameSettings, GameMode, Version, BOT_LEVELS } from "../../lib/gameLogic";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { motion, AnimatePresence } from "framer-motion";

interface SetupScreenProps {
  initialSettings: GameSettings;
  onStart: (settings: GameSettings) => void;
}

const VERSIONS: Version[] = ["20", "19", "18", "17", "B"];

const RULES = {
  cz: {
    title: "Pravidla — Bob's 27",
    sections: [
      {
        heading: "Cíl hry",
        text: "Zahrát co nejvíce double od D1 do D20 a Bullseye. Začínáš s 27 body, celkem 21 kol.",
      },
      {
        heading: "Každé kolo",
        text: "Hážeš 3 šipky na aktuální double. Za každý trefený double dostaneš jeho dvojnásobnou hodnotu (např. D4 = 8 bodů). Netrefíš-li žádný double, odečte se hodnota double od skóre.",
      },
      {
        heading: "Vstupní šipka",
        text: "1. šipka slouží ke vstupu do kola — single (S) nebo triple/double (T/D). Single body nedává. Triple/double body jsou podmíněné: připočtou se jen tehdy, pokud ve stejném kole trefíš double.",
      },
      {
        heading: "Bull (kolo 21)",
        text: "Finální kolo cílí na Bullseye (25). Bull má hodnotu 3× aktuální double. Bull je dostupný pouze jako 3. šipka po trefení double.",
      },
      {
        heading: "Módy",
        text: "CLASSIC (S/T): vstup je single nebo triple. PRO (S/D): vstup je single nebo double.",
      },
      {
        heading: "Konec hry",
        text: "Skóre klesne pod 0 = BUST a hra končí. Jinak hraješ všech 21 kol.",
      },
    ],
  },
  en: {
    title: "Rules — Bob's 27",
    sections: [
      {
        heading: "Objective",
        text: "Hit as many doubles as possible from D1 to D20 and Bullseye. You start with 27 points across 21 rounds.",
      },
      {
        heading: "Each round",
        text: "Throw 3 darts at the current double. Each double hit scores double its face value (e.g. D4 = 8 pts). If you miss all doubles, the double value is subtracted from your score.",
      },
      {
        heading: "Entry dart",
        text: "Dart 1 is the entry dart — single (S) or triple/double (T/D). Single scores nothing. Triple/double points are conditional: they are added only if you hit the double in the same round.",
      },
      {
        heading: "Bull (round 21)",
        text: "The final round targets Bullseye (25). Bull scores 3× the current double value. Bull is only available as the 3rd dart after hitting a double.",
      },
      {
        heading: "Modes",
        text: "CLASSIC (S/T): entry dart is single or triple. PRO (S/D): entry dart is single or double.",
      },
      {
        heading: "Game over",
        text: "If your score drops below 0 it's a BUST and the game ends. Otherwise all 21 rounds are played.",
      },
    ],
  },
};

export default function SetupScreen({ initialSettings, onStart }: SetupScreenProps) {
  const [playerName, setPlayerName] = useState(initialSettings.playerName);
  const [player2Name, setPlayer2Name] = useState(initialSettings.player2Name);
  const [playerCount, setPlayerCount] = useState<1 | 2 | "BOT">(initialSettings.playerCount);
  const [botLevelId, setBotLevelId] = useState<number>(initialSettings.botLevelId ?? 3);
  const [gameMode, setGameMode] = useState<GameMode>(initialSettings.gameMode);
  const [version, setVersion] = useState<Version>(initialSettings.version);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [rulesLang, setRulesLang] = useState<"cz" | "en">("cz");

  const handleStart = () => {
    onStart({ playerName, player2Name, playerCount, gameMode, version, botLevelId });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md mx-auto p-6 pt-10 flex flex-col gap-6"
    >
      <div className="text-center space-y-1">
        <h1 className="text-4xl font-bold tracking-tight text-primary">Super Bob's 27 🎯</h1>
        <p className="text-muted-foreground text-sm">The ultimate darts training app</p>
      </div>

      {/* Player Count */}
      <div className="space-y-3">
        <Label className="text-base">Mode</Label>
        <div className="grid grid-cols-3 gap-2">
          <Button
            variant={playerCount === 1 ? "default" : "outline"}
            onClick={() => setPlayerCount(1)}
            className="py-5 text-sm font-bold"
            data-testid="button-players-1"
          >
            1 PLAYER
          </Button>
          <Button
            variant={playerCount === 2 ? "default" : "outline"}
            onClick={() => setPlayerCount(2)}
            className="py-5 text-sm font-bold"
            data-testid="button-players-2"
          >
            2 PLAYERS
          </Button>
          <Button
            variant={playerCount === "BOT" ? "default" : "outline"}
            onClick={() => setPlayerCount("BOT")}
            className="py-5 text-sm font-bold"
            data-testid="button-players-bot"
          >
            VS BOT
          </Button>
        </div>
      </div>

      {/* Player Names */}
      <div className="space-y-3">
        <Label htmlFor="playerName" className="text-base">
          {playerCount === 2 ? "Player 1 Name" : "Your Name"}
        </Label>
        <Input
          id="playerName"
          value={playerName}
          onChange={(e) => setPlayerName(e.target.value)}
          className="text-lg py-5 bg-card"
          data-testid="input-player-name"
        />
      </div>

      <AnimatePresence>
        {playerCount === 2 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-3 overflow-hidden"
          >
            <Label htmlFor="player2Name" className="text-base">Player 2 Name</Label>
            <Input
              id="player2Name"
              value={player2Name}
              onChange={(e) => setPlayer2Name(e.target.value)}
              className="text-lg py-5 bg-card"
              data-testid="input-player2-name"
            />
          </motion.div>
        )}

        {playerCount === "BOT" && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-3 overflow-hidden"
          >
            <Label className="text-base">Bot Level</Label>
            <div className="grid grid-cols-2 gap-2">
              {BOT_LEVELS.map(level => (
                <button
                  key={level.id}
                  onClick={() => setBotLevelId(level.id)}
                  data-testid={`button-bot-level-${level.id}`}
                  className={`flex items-center gap-2 p-3 rounded-xl border text-left transition-all ${
                    botLevelId === level.id
                      ? "border-primary bg-primary/10 text-white"
                      : "border-border bg-card text-muted-foreground hover:border-primary/50"
                  }`}
                >
                  <span className="text-xl">{level.icon}</span>
                  <div className="min-w-0">
                    <div className="text-xs font-black uppercase tracking-wide truncate">
                      {level.name}
                    </div>
                    <div className="text-xs opacity-60 truncate">{level.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Game Mode */}
      <div className="space-y-3">
        <Label className="text-base">Game Mode</Label>
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant={gameMode === "CLASSIC" ? "default" : "outline"}
            onClick={() => setGameMode("CLASSIC")}
            className="py-5 text-base"
            data-testid="button-mode-classic"
          >
            CLASSIC (S/T)
          </Button>
          <Button
            variant={gameMode === "PRO" ? "default" : "outline"}
            onClick={() => setGameMode("PRO")}
            className="py-5 text-base"
            data-testid="button-mode-pro"
          >
            PRO (S/D)
          </Button>
        </div>
      </div>

      {/* Version */}
      <div className="space-y-3">
        <Label className="text-base">Target Version</Label>
        <div className="grid grid-cols-5 gap-2">
          {VERSIONS.map(v => (
            <Button
              key={v}
              variant={version === v ? "default" : "outline"}
              onClick={() => setVersion(v)}
              className="py-5 text-base"
              data-testid={`button-version-${v}`}
            >
              {v}
            </Button>
          ))}
        </div>
      </div>

      {/* Rules */}
      <div className="rounded-xl border border-border overflow-hidden">
        <button
          className="w-full flex items-center justify-between px-4 py-3 bg-card hover:bg-muted/40 transition-colors text-left"
          onClick={() => setRulesOpen(o => !o)}
        >
          <span className="font-bold text-sm tracking-wide uppercase text-muted-foreground">
            📋 Pravidla / Rules
          </span>
          <div className="flex items-center gap-2">
            {rulesOpen && (
              <div className="flex gap-1">
                <button
                  onClick={e => { e.stopPropagation(); setRulesLang("cz"); }}
                  className={`text-xs px-2 py-0.5 rounded font-bold transition-colors ${rulesLang === "cz" ? "bg-primary text-black" : "bg-muted text-muted-foreground"}`}
                >CZ</button>
                <button
                  onClick={e => { e.stopPropagation(); setRulesLang("en"); }}
                  className={`text-xs px-2 py-0.5 rounded font-bold transition-colors ${rulesLang === "en" ? "bg-primary text-black" : "bg-muted text-muted-foreground"}`}
                >EN</button>
              </div>
            )}
            <span className="text-muted-foreground text-lg">{rulesOpen ? "▲" : "▼"}</span>
          </div>
        </button>

        <AnimatePresence initial={false}>
          {rulesOpen && (
            <motion.div
              key="rules"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="px-4 py-4 space-y-3 bg-card/50">
                {RULES[rulesLang].sections.map(s => (
                  <div key={s.heading}>
                    <p className="text-xs font-black uppercase tracking-widest text-primary mb-0.5">{s.heading}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{s.text}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <Button
        size="lg"
        className="w-full py-7 text-2xl font-bold mt-2"
        onClick={handleStart}
        data-testid="button-start-game"
      >
        START GAME
      </Button>
    </motion.div>
  );
}
