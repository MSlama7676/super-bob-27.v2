export type GameMode = "CLASSIC" | "PRO"; // ST vs SD
export type Version = "20" | "19" | "18" | "17" | "B";

export interface GameSettings {
  playerName: string;
  player2Name: string;
  playerCount: 1 | 2 | "BOT";
  gameMode: GameMode;
  version: Version;
  botLevelId?: number; // 1–8
}

export interface GameState {
  score: number;
  currentDouble: number; // 1 to 20, then 25 (Bull)
  round: number; // 1 to 21
  dartsRemaining: number; // 3 to 0
  enteredGame: boolean;
  doubleHit: boolean;
  hits: number;
  totalDartsThrown: number;
  status: "PLAYING" | "WON" | "BUST";
  /** Points from T/D entry, only added to score if a double is hit this round */
  pendingEntryBonus: number;
}

export type Action =
  | { type: "ENTRY"; value: number }
  | { type: "DOUBLE" }
  | { type: "BULLSEYE_BONUS" }
  | { type: "NEXT_ROUND" }
  | { type: "UNDO" }
  | { type: "EXIT" };

export interface RoundResult {
  roundNumber: number;
  currentDouble: number;
  finalScore: number;
  bust: boolean;
  doubleHit: boolean;
  dartsThrown: number;
  hits: number;
}

export const getEntryValue = (version: Version): number => {
  if (version === "B") return 25;
  return parseInt(version, 10);
};

// ─── Bot system ────────────────────────────────────────────────────────────────

export interface BotLevel {
  id: number;
  icon: string;
  name: string;
  desc: string;
  entryRate: number;
  doubleRate: number;
  bullRate: number;
  /** 0–1: chance bot goes for T/D entry (scoring) vs S (no points) */
  multiEntryRate: number;
  /** 0–1: chance bot attempts bull on dart 3 when double already hit */
  bullAttemptRate: number;
}

export const BOT_LEVELS: BotLevel[] = [
  { id: 1, icon: "🍺", name: "Beginner",        desc: "Pub beginner",           entryRate: 0.35, doubleRate: 0.10, bullRate: 0.01, multiEntryRate: 0.30, bullAttemptRate: 0.05 },
  { id: 2, icon: "🎱", name: "Casual Player",    desc: "Occasional league",      entryRate: 0.50, doubleRate: 0.20, bullRate: 0.03, multiEntryRate: 0.40, bullAttemptRate: 0.10 },
  { id: 3, icon: "🏅", name: "Club Player",      desc: "Regular local league",   entryRate: 0.65, doubleRate: 0.30, bullRate: 0.05, multiEntryRate: 0.55, bullAttemptRate: 0.15 },
  { id: 4, icon: "⭐", name: "County Player",    desc: "Strong regional",        entryRate: 0.75, doubleRate: 0.40, bullRate: 0.08, multiEntryRate: 0.65, bullAttemptRate: 0.20 },
  { id: 5, icon: "🌍", name: "WDF Player",       desc: "National tournament",    entryRate: 0.85, doubleRate: 0.50, bullRate: 0.12, multiEntryRate: 0.75, bullAttemptRate: 0.25 },
  { id: 6, icon: "🏆", name: "PDC Tour Card",    desc: "Professional player",    entryRate: 0.92, doubleRate: 0.60, bullRate: 0.18, multiEntryRate: 0.85, bullAttemptRate: 0.30 },
  { id: 7, icon: "👑", name: "PDC Elite",        desc: "Premier League level",   entryRate: 0.96, doubleRate: 0.70, bullRate: 0.25, multiEntryRate: 0.90, bullAttemptRate: 0.30 },
  { id: 8, icon: "🔥", name: "Luke Littler",     desc: "Ultimate challenge",     entryRate: 0.98, doubleRate: 0.80, bullRate: 0.35, multiEntryRate: 0.95, bullAttemptRate: 0.30 },
];

export type BotActionType =
  | "entry_multi"   // T20/D20 hit — gives points
  | "entry_single"  // S20 hit — no points, just entry
  | "entry_miss"    // missed entry
  | "double_hit"    // hit the target double
  | "double_miss"   // missed the target double
  | "bull_hit"      // bull bonus hit
  | "bull_miss";    // bull bonus missed

export interface BotDartAction {
  actionType: BotActionType;
  points: number;
  label: string; // display label e.g. "T20", "D5", "BULL"
}

export interface BotRoundResult {
  round: number;
  currentDouble: number;
  darts: BotDartAction[];
  penalty: number;       // negative if miss penalty applied
  scoreAfter: number;
  doubleHit: boolean;
  bust: boolean;
}

export function getDoubleValue(currentDouble: number): number {
  if (currentDouble === 25) return 50;
  return currentDouble * 2;
}

function roll(rate: number): boolean {
  return Math.random() < rate;
}

/** Simulate entire bot game. Returns array of round results. */
export function simulateBotGame(settings: GameSettings, level: BotLevel): BotRoundResult[] {
  const rounds: BotRoundResult[] = [];
  let score = 27;
  let currentDouble = 1;
  const entryValue = getEntryValue(settings.version);
  const entryMultiplier = settings.gameMode === "CLASSIC" ? 3 : 2;
  const entryMultiLabel = settings.gameMode === "CLASSIC" ? `T${settings.version}` : `D${settings.version}`;
  const entrySingleLabel = `S${settings.version === "B" ? "B" : settings.version}`;

  for (let round = 1; round <= 21; round++) {
    const doubleVal = getDoubleValue(currentDouble);
    const targetLabel = currentDouble === 25 ? "DB" : `D${currentDouble}`;
    const darts: BotDartAction[] = [];
    let enteredGame = false;
    let doubleHit = false;
    let roundPoints = 0;

    // ── Dart 1: entry ──────────────────────────────────────────────
    let pendingEntryBonus = 0;
    if (roll(level.entryRate)) {
      const goMulti = roll(level.multiEntryRate);
      if (goMulti) {
        const pts = entryValue * entryMultiplier;
        // T/D entry points are PENDING — only counted if a double is hit this round
        pendingEntryBonus = pts;
        darts.push({ actionType: "entry_multi", points: pts, label: entryMultiLabel });
      } else {
        darts.push({ actionType: "entry_single", points: 0, label: entrySingleLabel });
      }
      enteredGame = true;
    } else {
      darts.push({ actionType: "entry_miss", points: 0, label: entrySingleLabel });
    }

    // ── Dart 2: double attempt (only if entered) ───────────────────
    if (enteredGame) {
      if (roll(level.doubleRate)) {
        roundPoints += doubleVal;
        doubleHit = true;
        darts.push({ actionType: "double_hit", points: doubleVal, label: targetLabel });
      } else {
        darts.push({ actionType: "double_miss", points: 0, label: targetLabel });
      }
    } else {
      // Dart 2 wasted (no entry)
      darts.push({ actionType: "double_miss", points: 0, label: targetLabel });
    }

    // ── Dart 3: double or bull ─────────────────────────────────────
    if (enteredGame) {
      const goBull = doubleHit && roll(level.bullAttemptRate);
      if (goBull) {
        if (roll(level.bullRate)) {
          const bullPts = doubleVal * 3;
          roundPoints += bullPts;
          darts.push({ actionType: "bull_hit", points: bullPts, label: "BULL" });
        } else {
          darts.push({ actionType: "bull_miss", points: 0, label: "BULL" });
        }
      } else {
        // Try double again
        if (roll(level.doubleRate)) {
          roundPoints += doubleVal;
          doubleHit = true;
          darts.push({ actionType: "double_hit", points: doubleVal, label: targetLabel });
        } else {
          darts.push({ actionType: "double_miss", points: 0, label: targetLabel });
        }
      }
    } else {
      darts.push({ actionType: "double_miss", points: 0, label: targetLabel });
    }

    // ── Apply pending entry bonus only if a double was hit ─────────
    if (doubleHit) {
      roundPoints += pendingEntryBonus;
    }

    // ── Penalty if no double hit ───────────────────────────────────
    const penalty = doubleHit ? 0 : -doubleVal;
    score += roundPoints + penalty;

    const bust = score < 0;
    rounds.push({ round, currentDouble, darts, penalty, scoreAfter: score, doubleHit, bust });

    if (bust) break;

    // Advance target
    let next = currentDouble + 1;
    if (next === 21) next = 25;
    currentDouble = next;
  }

  return rounds;
}
